export class Product {
  productId: number;
  productName: string;
  seller: string;
  description: string;
  productImage: string;
  cost: number;
}
